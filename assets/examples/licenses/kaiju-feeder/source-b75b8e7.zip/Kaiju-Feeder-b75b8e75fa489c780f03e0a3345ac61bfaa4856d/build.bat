cd src
make
cd ..
