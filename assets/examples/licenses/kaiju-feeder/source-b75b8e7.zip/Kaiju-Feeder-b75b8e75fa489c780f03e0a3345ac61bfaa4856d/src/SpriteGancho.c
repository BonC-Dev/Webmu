#include "Banks/SetAutoBank.h"

#include "SpriteManager.h"
#include "ZGBMain.h"
#include "Keys.h"

Sprite* sprite_gancho = 0;
extern Sprite* sprite_chopter;
extern Sprite* sprite_rope;

typedef struct {
	INT16 y;
	INT16 vy;
} CUSTOM_DATA;

void START(void) {
	CUSTOM_DATA* data = (CUSTOM_DATA*)THIS->custom_data;
	data->y = sprite_chopter->y + 16;
	data->vy = 1;
	sprite_gancho = THIS;

	SpriteManagerAdd(SpriteRope, THIS->x, THIS->y);
}

void UPDATE(void) {
	INT16 new_x;
	INT16 new_y;
	UINT8 i;
	Sprite* spr;

	CUSTOM_DATA* data = (CUSTOM_DATA*)THIS->custom_data;
	data->y += data->vy;

	new_x = sprite_chopter->x + 12;
	new_y = data->y;
	if(data->vy > 0) { //going down
		if(TranslateSprite(THIS, new_x - THIS->x, new_y - THIS->y)) {
			data->vy = -3;
		} else {
			SPRITEMANAGER_ITERATE(i, spr) {
				if(spr->type == SpritePollo) {
					if(CheckCollision(spr, THIS)) {
						SpriteManagerRemove(i);
						SetFrame(THIS, 1);
						data->vy = -1;
					}
				}
			}
		}
	} else { //going up
		if(THIS->anim_frame == 1) { //pollo grabbed
			if(TranslateSprite(THIS, new_x - THIS->x, new_y - THIS->y)) { //Gancho with pollo has collided
				SetFrame(THIS, 0);
				SpriteManagerAdd(SpritePollo, THIS->x - 12, THIS->y + 12);
			}
		} else { //no pollo, just go up
			THIS->x = new_x;
			THIS->y = new_y;
		}

		if(THIS->y < sprite_chopter->y + 16) { //Gancho is on chopter pos
			if (sprite_rope) {
				SpriteManagerRemoveSprite(sprite_rope);
			}
			if(THIS->anim_frame == 1) { //Pollo grabbed, keep the gancho
				data->y = sprite_chopter->y + 16;
			} else { //No pollo, remove gancho
				SpriteManagerRemoveSprite(THIS);
			}
		}

		if(KEY_TICKED(J_B) && THIS->anim_frame == 1) {
			//Drop the pollo
			SetFrame(THIS, 0);
			SpriteManagerAdd(SpritePollo, THIS->x - 12, THIS->y + 12);
		}
	}

	//Dont' move beyond chopter->y + 60
	if((data->y - sprite_chopter->y) > 60) {
		data->y = sprite_chopter->y + 60;
	}
}

void DESTROY(void) {
	sprite_gancho = 0;
}
